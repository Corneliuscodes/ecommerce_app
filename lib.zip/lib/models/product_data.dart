// ignore_for_file: unused_import

import 'package:flutter/material.dart';

class Product {
  String image;
  String words;

  Product({required this.image, required this.words});
}

List<Product> productData = [
  Product(
    image: 'assets/Ellipse 4.png',
    words: 'Beauty'
  ),
  Product(
    image: 'assets/unsplash__3Q3tsJ01nc.png',
    words: 'Fashion'
  ),
  Product(
    image: 'assets/unsplash_GCDjllzoKLo.png',
    words: 'Kids'
  ),
  Product(
    image: 'assets/unsplash_xPJYL0l5Ii8.png',
    words: 'Womens'
  ),
  Product(
    image: 'assets/unsplash_OYYE4g-I5ZQ.png',
    words: 'Mens'
  ),
  
  Product(
    image: 'assets/Ellipse 4.png',
    words: 'Beauty'
  ),
  Product(
    image: 'assets/unsplash__3Q3tsJ01nc.png',
    words: 'Fashion'
  ),
  Product(
    image: 'assets/unsplash_GCDjllzoKLo.png',
    words: 'Kids'
  ),
  Product(
    image: 'assets/unsplash_xPJYL0l5Ii8.png',
    words: 'Womens'
  ),
  Product(
    image: 'assets/unsplash_OYYE4g-I5ZQ.png',
    words: 'Mens'
  ),
  
];
