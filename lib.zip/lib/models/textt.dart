// ignore_for_file: unused_import

import 'package:flutter/material.dart';

class Txtt {
  String words;

  Txtt({required this.words});
}

List<Txtt> Textt = [
  Txtt(
    words: '6 UK'
  ),
  Txtt(
    words: '7 UK'
  ),
 Txtt(
    words: '8 UK'
  ),
  Txtt(
    words: '9 UK'
  ),
  Txtt(
    words: '10 UK'
  ),
  
  
];
