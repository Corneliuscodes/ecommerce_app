// ignore_for_file: unused_import

import 'package:flutter/material.dart';

class Cont {
  String image;
  String words;

  Cont({required this.image, required this.words});
}

List<Cont> ContListt = [
  Cont(
    image: 'assets/visa 1.png',
    words: '*********2109'
  ),
  Cont(
    image: 'assets/paypal 1.png',
    words: '*********2109'
  ),
 Cont(
    image: 'assets/maestro 1.png',
    words: '*********2109'
  ),
  Cont(
    image: 'assets/Sign in with Apple (Logo-only).png',
    words: '*********2109'
  ),
  
  
];
