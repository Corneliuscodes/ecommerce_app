// ignore_for_file: unused_import

import 'package:flutter/material.dart';

class Gridd {
  String image;
  String words;
  String price;
  String crossed;
  String title;

 Gridd ({required this.image, required this.words, required this.crossed, required this.price, required this.title});
}

List<Gridd > Griddy = [
   Gridd (
    image: 'assets/unsplash_NoVnXXmDNi0 (1).png',
    title: 'Black Winter...',
    words: 'Autumn And Winter Casual cotton-padded jacket...',
    price:'₹499',
    crossed:'6,890',
  ),
  Gridd (
    image: 'assets/unsplash_0vsk2_9dkqo.png',
    title: 'Mens Starry',
    words: 'Mens Starry Sky Printed Shirt 100% Cotton Fabric',
    price:'₹399',
    crossed:'152,344',
  ),
   Gridd (
    image: 'assets/unsplash_yTBMYCcZQRs.png',
    title: 'Mens Starry',
    words: 'Mens Starry Sky Printed Shirt 100% Cotton Fabric',
    price:'₹399',
    crossed:'152,344',
  ),
   Gridd (
    image: 'assets/unsplash_Pdds9XsWyoM.png',
    title: 'Nike Sneakers',
    words: 'Mid Peach Mocha Shoes For \nMan White Black Pink S...',
    price:'₹1900',
    crossed:'2,568',
  ),
   Gridd (
    image: 'assets/unsplash_NoVnXXmDNi0 (1).png',
    title: 'Black Winter...',
    words: 'Autumn And Winter Casual cotton-padded jacket...',
    price:'₹499',
    crossed:'6,890',
  ),
  Gridd (
    image: 'assets/unsplash_0vsk2_9dkqo.png',
    title: 'Mens Starry',
    words: 'Mens Starry Sky Printed Shirt 100% Cotton Fabric',
    price:'₹399',
    crossed:'152,344',
  ),
   Gridd (
    image: 'assets/unsplash_yTBMYCcZQRs.png',
    title: 'Mens Starry',
    words: 'Mens Starry Sky Printed Shirt 100% Cotton Fabric',
    price:'₹399',
    crossed:'152,344',
  ),
   Gridd (
    image: 'assets/unsplash_Pdds9XsWyoM.png',
    title: 'Nike Sneakers',
    words: 'Mid Peach Mocha Shoes For \nMan White Black Pink S...',
    price:'₹1900',
    crossed:'2,568',
  ),
   Gridd (
    image: 'assets/unsplash_9U18fiowwbw (2).png',
    title: 'Mens Starry',
    words: 'Mens Starry Sky Printed Shirt 100% Cotton Fabric',
    price:'₹399',
    crossed:'152,344',
  ),
   Gridd (
    image: 'assets/unsplash_0vsk2_9dkqo (3).png',
    title: 'Nike Sneakers',
    words: 'Mid Peach Mocha Shoes For \nMan White Black Pink S...',
    price:'₹1900',
    crossed:'2,568',
  ),
   
];
